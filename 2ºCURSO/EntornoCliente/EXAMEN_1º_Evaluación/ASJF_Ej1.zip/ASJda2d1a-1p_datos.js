// campos: idproducto,precio,producto
const productos = `54-AAISZ-0yG,370.68,graphics card
54-QUXGG-s2L,145.12,SSD
53-ECLSG-N5i,974.66,
57-YNVWX-Zrn,908.19,headphones
84-YIPNJ-Asm,166.74,CPU
00-ZYSCT-pWF,,speakers
37-SFMZF-TR2,366.27,laptop
94-GDGSD-CRe,,CPU
73-TKVXY-eQx,,RAM
03-ALXSK-aH4,685.45,graphics card
60-EFQQN-W9p,402.22,speakers
83-VZNDF-MA5,249.24,USB flash drive
56-MMRLL-CNC,549.37,gaming headset
60-UUFRX-XPU,108.99,external hard drive
48-FOQIU-4Vq,338.88,motherboard
61-FYCQN-Kc8,979.8,laptop
72-UJJXV-6si,792.46,headphones
34-VAQRO-9r2,817.42,webcam
43-VOMLR-PNA,435.08,wireless mouse
59-ISUAE-9KS,627.88,laptop
06-FCEBC-g9A,774.88,microphone
08-UOUQY-EzY,,
76-CNDEC-8aQ,,wireless mouse
70-QGZRO-qwn,948.61,monitor
06-PCMIJ-lhB,630.63,webcam
22-KYQQE-Dm0,374.05,wireless mouse
12-PQGMM-tmN,405.41,USB flash drive
97-LRELW-pzE,,router
23-TACXP-erj,405.45,router
49-XOKVW-tUf,368.81,external hard drive
70-CSIZY-KWa,704.29,microphone
47-QBUVS-9Xk,702.34,SSD`;
