const usuario = document.getElementById("colu");
const empresa = document.getElementById("cole");
const ciudad = document.getElementById("colc");
const lienzo = document.getElementById("lienzo");

usuario.addEventListener("click",listarUsuarios);
empresa.addEventListener("click",listarEmpresas);
usuario.addEventListener("click",listarCiudades);

let listaregistros = [];
listaregistros = listaUsuarios.split('\n'); 
let  lista = [];

crearObjetosUsuarios();

function crearObjetosUsuarios() {
    for(let i = 0; i< listaregistros.length;i++){
       let registro =listaregistros[i].split(','); 
        let objeto = {
                usuario: registro[0],
                empresa: registro[1],
                direccion: registro[2]
        }
        lista [i]= objeto;
    }
}

function listarUsuarios() {
    for(let i = 0; i<lista.length;i++){
      text = lista[i].usuario;
      lienzo.innerHTML = text;
    }
  
}

function listarEmpresas() {}

function listarCiudades() {}

function listarUsuariosEmpresas() {}

function listarUsuariosCiudades() {}

function listarTodo() {}

function asignarEventos() {}
