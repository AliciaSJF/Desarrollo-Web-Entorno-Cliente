let listaregistros = [];

function crearObjetosUsuarios() {}

function listarUsuarios() {}

function listarEmpresas() {}

function listarCiudades() {}

function listarUsuariosEmpresas() {}

function listarUsuariosCiudades() {}

function listarTodo() {}

function asignarEventos() {}
